package struct;

public class StockStruct extends Struct{
	public String timeStamp;
	public String user;
	public int productNo;
	public String warehouseCd;
	public String stockType;
	public String productCd;
	public int quantityBeforeReserve;
	public int quantityAfterReserve;
	
}
