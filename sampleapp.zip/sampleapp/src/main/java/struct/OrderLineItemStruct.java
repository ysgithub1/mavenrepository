package struct;

import java.util.ArrayList;



public class OrderLineItemStruct extends Struct{
	public int orderNo;
	public int lineItemNo;
	public short reservedStatus;
	public int reservedProductNo;
	public int reservedQuantity;
	
}
