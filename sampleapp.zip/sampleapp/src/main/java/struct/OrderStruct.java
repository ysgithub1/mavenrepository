package struct;

import java.util.ArrayList;



public class OrderStruct extends Struct{
	public int orderNo;
	public String deliveryDate;
	public int orderQuantity;
	public int remainingQuantity;
	public short orderStatus;
}
