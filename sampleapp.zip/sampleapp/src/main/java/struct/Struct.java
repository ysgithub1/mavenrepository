package struct;

import java.math.BigDecimal;

public class Struct {
	public int jurisdiction;
	public String agentCd;
	public String productCd;
	public BigDecimal size;
}
