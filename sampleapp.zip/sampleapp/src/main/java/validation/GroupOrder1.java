package validation;

public interface GroupOrder1 {

}
