package validation;

public interface GroupOrder2 {

}
