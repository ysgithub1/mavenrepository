package validation;
import javax.validation.GroupSequence;

@GroupSequence({GroupOrder1.class, GroupOrder2.class})	
public interface GroupOrder {

}
