package com;

public class Head {
	private String head="";
	public  Head(String title){
		 this.head += "<head>" + "\n";
		 this.head += "<meta charset=\"utf-8\">" + "\n";
		 this.head += "<title>" + title + "</title>" + "\n";
		 this.head += "</head>" + "\n";
	}
	public String getHead() {
		return this.head;
	}
	
}
