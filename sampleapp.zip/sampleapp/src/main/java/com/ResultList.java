package com;

public class ResultList {

}
